package com.example.storex_storageexpert;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;

public class SearchActivity extends AppCompatActivity {

    EditText etSearch;
    ListView listViewSearch;
    ArrayAdapter<String> adapter;
    ArrayList<String> itemList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchactivity);

        etSearch = findViewById(R.id.etSearch);
        listViewSearch = findViewById(R.id.listViewSearch);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
        listViewSearch.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 1) {
                    searchData(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void searchData(String keyword) {
        class SearchData extends AsyncTask<Void, Void, String> {
            ProgressDialog dialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                dialog = ProgressDialog.show(SearchActivity.this, "Searching...", "Loading...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                dialog.dismiss();

                itemList.clear();
                try {
                    JSONObject obj = new JSONObject(s);
                    if (obj.getBoolean("status")) {
                        JSONArray data = obj.getJSONArray("data");

                        for (int i = 0; i < data.length(); i++) {
                            JSONObject item = data.getJSONObject(i);
                            String namaProduk = item.getString("nama_produk");
                            itemList.add(namaProduk);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            protected String doInBackground(Void... voids) {
                HashMap<String, String> params = new HashMap<>();
                params.put("keyword", keyword);
                RequestHandler rh = new RequestHandler();
                return rh.sendPostRequest(konfigurasi.BASE_URL + "search_produk.php", params);
            }
        }

        SearchData search = new SearchData();
        search.execute();
    }
}