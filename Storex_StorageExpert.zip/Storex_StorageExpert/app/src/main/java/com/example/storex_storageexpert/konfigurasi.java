package com.example.storex_storageexpert;

public class konfigurasi {
    // Ganti IP Address dari sini aja
    public static final String BASE_IP = "192.168.87.9";
    public static final String BASE_URL = "http://" + BASE_IP + "/storex_php/";

    public static final String URL_ADD = BASE_URL + "tambahpegawai.php";
    public static final String URL_GET_ALL = BASE_URL + "tampilSemuaPgw.php";
    public static final String URL_GET_EMP = BASE_URL + "tampilPegawai.php";
    public static final String URL_UPDATE_EMP = BASE_URL + "updatePegawai.php";
    public static final String URL_DELETE_EMP = BASE_URL + "hapusPegawai.php";

    public static final String KEY_EMP_ID = "id";
    public static final String KEY_EMP_NAMA = "nama";
    public static final String KEY_EMP_POSISI = "posisi";
    public static final String KEY_EMP_GAJI = "gaji";

    public static final String TAG_JSON_ARRAY = "result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_POSISI = "posisi";
    public static final String TAG_GAJI = "gaji";

    public static final String EMP_ID = "emp_id";
}

