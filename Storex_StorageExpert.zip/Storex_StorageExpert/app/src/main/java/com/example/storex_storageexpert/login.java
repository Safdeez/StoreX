package com.example.storex_storageexpert;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class login extends AppCompatActivity {

    EditText etEmail, etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            login();
        });
    }

    private void login() {
        class Login extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(login.this, "Login...", "Wait...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();

                if (checkValid(s)) {
                    Toast.makeText(login.this, "Login berhasil", Toast.LENGTH_SHORT).show();
                    // Arahkan ke halaman utama atau dashboard
                    Intent intent = new Intent(login.this, HomeActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(login.this, "Email atau password salah.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> data = new HashMap<>();
                data.put("email", etEmail.getText().toString().trim());
                data.put("password", etPassword.getText().toString().trim());

                RequestHandler rh = new RequestHandler();
                return rh.sendPostRequest(konfigurasi.BASE_URL + "login.php", data);
            }
        }
        Login ge = new Login();
        ge.execute();
    }

    private boolean checkValid(String json) {
        try {
            JSONArray jsonArr = new JSONArray(json);
            JSONObject c = jsonArr.getJSONObject(0);

            String success = c.getString("success");

            return success.equals("true");
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }
}